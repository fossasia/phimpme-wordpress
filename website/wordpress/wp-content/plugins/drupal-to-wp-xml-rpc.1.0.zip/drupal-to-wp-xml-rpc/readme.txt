=== Drupal to WP XML-RPC ===
Contributors: aliciagh
Tags: multisite, xmlrpc, drupal, drupaltowp
Requires at least: 3.0
Tested up to: 3.0.4
Stable tag: 1.0

Adds some Multisite-specific functions to WordPress XML-RPC interface.

== Description ==

Adds some Multisite-specific functions to WordPress XML-RPC interface (http://yourdomain.com/xmlrpc.php).
This plugin is required for the correct work of a Drupal module named Drupal to WP.

**Functions availables**

* drupal.newBlog - Create a new blog
* drupal.getUsers - Get all users of your installation
* drupal.getUsersBlogs - Get blogs of a user
* drupal.getBlogId - Get a blog ID
* drupal.getCategories - Get a list of categories on a given blog
* drupal.newUser - Create a new user
* drupal.deleteUser - Delete a user

Functions return error code 700 or 403 if there are problems with authetication and error code 500 if there are other problem.

== Installation ==
1. Upload `drupaltowp_xmlrpc` folder to the `wp-content/plugins` directory in your WordPress multisite installation.
2. Activate the plugin in your Administration Panel.
3. Check 'Enable the WordPress, Movable Type, MetaWeblog and Blogger XML-RPC publishing protocols' through 'Writing' menu and click 'Save Changes'.

**Requeriments**

* Its neccesary to activate mcrypt support in PHP.

== Frequently Asked Questions ==

If you have any further questions, please submit them.

= Get XML-RPC error `Combination of username/password incorrect` =

Check username and password are correct.
Password must be encrypted before calling one of this xml-rpc functions so follow this steps:
1. Open file `drupaltowp_xmlrpc.php` and copy the function `drupaltowp_encrypt_password` to your code.
2. Define a key for encrypting your passwords. Max 20 characters.
3. Edit file `drupaltowp_xmlrpc.php` and put your key value in line 32: `define( 'DRUPALTOWP_KEY', 'your-key-value' );`
